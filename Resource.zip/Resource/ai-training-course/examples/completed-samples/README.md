# Completed Samples - Course 1

Tài liệu này chứa các ví dụ minh họa đã được điền đầy đủ, mô phỏng sản phẩm hoàn chỉnh mà một lập trình viên có thể tạo ra khi dùng AI trong thực tế.

## Cách dùng
- Đọc file completed sample như một sản phẩm hoàn chỉnh.
- So sánh với template hoặc lab sheet để hiểu cấu trúc.
- Dùng làm reference khi tự làm bài hoặc khi giảng dạy.

## Danh mục

### Artifacts hoàn chỉnh
- [Project Understanding Report](course-1/project-understanding-report-complete.md)
- [Prompt Playbook](course-1/prompt-playbook-complete.md)
- [AI Decision Log](course-1/ai-decision-log-complete.md)
- [Reflection Report](course-1/reflection-report-complete.md)
- [PR Description & Verification](course-1/pr-description-and-verification-complete.md)

### Prompt + output worked examples
- [Worked Example - Prompt Refinement](course-1/worked-example-prompt-refinement.md)
- [Worked Example - Context Packing](course-1/worked-example-context-packing.md)
- [Worked Example - PR Review](course-1/worked-example-pr-review.md)

## Nguyên tắc của completed samples
- Nội dung đầy đủ, không còn placeholder.
- Có bối cảnh rõ ràng cho repository mẫu E-commerce Backend API.
- Có kết quả cụ thể để người học nhìn thấy sản phẩm cuối.
- Có thể dùng làm reference cho mức trung bình khá trở lên.
