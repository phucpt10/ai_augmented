# Course 1 Workshop System

Bộ tài liệu này tổ chức các workshop của Course 1 theo 3 slot dạy. Mỗi workshop có mục tiêu, yêu cầu, tài nguyên, hướng dẫn cho giảng viên và sinh viên, đầu ra, kiểm chứng và rubric chấm điểm rõ ràng.

## Cấu trúc

### Slot 1 - Nền tảng và hiểu hệ thống
- [Workshop S1-01: AI-Augmented SE Overview](slot-1/s1-01-ai-augmented-se-overview.md)
- [Workshop S1-02: Repository Exploration](slot-1/s1-02-repository-exploration.md)
- [Workshop S1-03: Project Understanding Presentation](slot-1/s1-03-project-understanding-presentation.md)

### Slot 2 - Prompt, context và workflow AI
- [Workshop S2-01: Prompt Refinement](slot-2/s2-01-prompt-refinement.md)
- [Workshop S2-02: Context Packing](slot-2/s2-02-context-packing.md)
- [Workshop S2-03: Prompt Playbook Building](slot-2/s2-03-prompt-playbook-building.md)

### Slot 3 - Pair programming, feature development, review và reflection
- [Workshop S3-01: Requirement to Task Breakdown](slot-3/s3-01-requirement-to-task-breakdown.md)
- [Workshop S3-02: AI-assisted Feature Implementation](slot-3/s3-02-ai-assisted-feature-implementation.md)
- [Workshop S3-03: PR Review and Reflection](slot-3/s3-03-pr-review-and-reflection.md)

## Nguyên tắc dùng chung
- Dùng sample repository E-commerce Backend API làm bối cảnh chính.
- Dùng cùng một business flow xuyên suốt, ưu tiên user registration hoặc order creation.
- Mỗi workshop có input, thao tác, output, verification và reflection.
- Độ khó tăng dần từ hiểu hệ thống đến làm việc end-to-end với AI.

## Tài nguyên dùng chung
- [Course 1 3 Slot Workshop Outline](../course-1-3-slot-workshop-outline.md)
- [Course 1 Rubric Tổng Hợp](course-1-rubric-overview.md)
- [Bộ Phiếu Nộp Bài Theo Workshop](submissions/README.md)
- [Lab Sheet Template](../../common/lab-sheet-template.md)
- [Prompt Pack](../../common/prompt-pack.md)
- [Sample Repository Context Pack](../../common/sample-repository-context.md)
- [Workflow Pack](../../common/workflow-pack.md)
