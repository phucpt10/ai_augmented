# Course 3 - Database Design with AI

## 1. Mục tiêu
- Thiết kế data model và schema với AI.
- Sinh query và sample data.

## 2. Bối cảnh
- **Tình huống:** Thêm review model cho e-commerce backend.
- **Repository:** Sample E-commerce Backend API
- **Tool sử dụng:** AI assistant, ERD tool, SQL editor

## 3. Dữ liệu đầu vào mẫu
### Prompt mẫu
```text
Thiết kế schema cho Product, Review và User.

Yêu cầu:
1. Nêu entity và relationship.
2. Đề xuất primary key và foreign key.
3. Viết query mẫu.
4. Tạo sample data.
```

## 4. Các bước thực hiện
1. Định nghĩa entity và relationship.
2. Hỏi AI đề xuất schema.
3. So sánh với business rules.
4. Sinh sample data.
5. Kiểm chứng bằng query.

## 5. Kiểm chứng kết quả
- Schema có normalize hợp lý không?
- Quan hệ có đúng business rule không?
- Query mẫu có chạy được không?

## 6. Kết quả mong đợi
- Database Design Document.
