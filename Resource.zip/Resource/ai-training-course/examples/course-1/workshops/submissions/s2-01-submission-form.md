# Submission Form - Workshop S2-01

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- Prompt gốc.
- Prompt đã cải tiến.
- So sánh output trước và sau.

## 3. Context sử dụng
- File code đã chọn:
- AI tool đã dùng:
- Mục tiêu prompt:

## 4. Kết quả thực hiện
- Điểm yếu của prompt gốc:
- Điểm cải tiến của prompt mới:
- Prompt nào sẽ đưa vào playbook:

## 5. Evidence / kiểm chứng
- Output trước:
- Output sau:
- Tiêu chí nào đã cải thiện rõ nhất:

## 6. Reflection
- Thay đổi nào có tác động lớn nhất?
- Tôi còn cần cải thiện kỹ năng prompt ở điểm nào?
