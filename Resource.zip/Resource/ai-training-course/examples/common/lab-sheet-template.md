# Lab Sheet Template

## 1. Title
[Tên lab sheet]

## 2. Learning Goal
- [Mục tiêu 1]
- [Mục tiêu 2]
- [Mục tiêu 3]

## 3. Scenario
- **Module:** [Tên module]
- **Use case:** [Tình huống thực chiến]
- **Repository:** [Sample repository hoặc project khác]
- **Tools:** [AI assistant, IDE, Git, test runner, PR tool]

## 4. Prerequisites
### 4.1 Accounts / Access
- [ ] Access to repository
- [ ] AI assistant account
- [ ] Git account hoặc Git remote access

### 4.2 Setup
- [ ] Clone repository
- [ ] Open project in VS Code
- [ ] Install dependencies
- [ ] Run project or tests once

### 4.3 Sample Data / Input
- [Requirement / bug report / code snippet / PR diff]
- [File paths liên quan]

## 5. Step-by-step Instructions
### Step 1: Prepare context
### Step 2: Run the prompt or action
### Step 3: Inspect AI output
### Step 4: Refine prompt / context if needed
### Step 5: Apply changes in code or docs
### Step 6: Verify result with test or manual check
### Step 7: Record outcome

## 6. Verification Checklist
- [ ] Correctness
- [ ] Security
- [ ] Test coverage
- [ ] Performance if relevant
- [ ] Documentation if relevant
- [ ] Human review

## 7. Expected Output
- [Output 1]
- [Output 2]
- [Output 3]

## 8. Common Mistakes
- [Mistake 1]
- [Mistake 2]
- [Mistake 3]

## 9. Reflection Questions
- What worked well?
- What did AI miss?
- What would you change next time?

## 10. Facilitator Notes
- [Ghi chú cho giảng viên]
