# Workshop Submission Form Template

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Workshop:
- Ngày nộp:

## 2. Mục tiêu bài làm
- Tôi hiểu workshop này nhằm giải quyết vấn đề gì:
- Deliverable chính tôi cần nộp là:

## 3. Tài nguyên đã sử dụng
- Repository / file context:
- AI tool:
- Prompt đã dùng:
- Tài liệu / template tham chiếu:

## 4. Kết quả thực hiện
- Tóm tắt những gì đã làm:
- Output chính:
- Link hoặc đường dẫn file nộp:

## 5. Evidence / kiểm chứng
- Test / review / manual check đã thực hiện:
- Ảnh chụp / log / kết quả:
- Những điểm tôi đã xác minh thủ công:

## 6. Khó khăn gặp phải
- Khó khăn 1:
- Khó khăn 2:
- Cách tôi xử lý:

## 7. Reflection ngắn
- AI giúp tôi tốt nhất ở đâu?
- AI trả lời sai hoặc thiếu ở đâu?
- Nếu làm lại, tôi sẽ thay đổi điều gì?

## 8. Tự đánh giá
- Mức độ hoàn thành: [Xuất sắc / Đạt / Chưa đạt]
- Lý do:
