# Course 1 Rubric Tổng Hợp

Tài liệu này tổng hợp rubric đánh giá cho toàn bộ Course 1 ở cấp độ slot và cấp độ workshop. Mục tiêu là giúp giảng viên chấm nhất quán, còn sinh viên hiểu rõ tiêu chí cần đạt.

## 1. Mục tiêu đánh giá
- Đánh giá mức độ hiểu hệ thống và khả năng làm việc với AI.
- Đánh giá chất lượng prompt, context, verification và workflow.
- Đánh giá khả năng tạo deliverable thực tế theo từng workshop.

## 2. Cấu trúc đánh giá toàn Course 1

### Slot 1 - Nền tảng và hiểu hệ thống
| Thành phần | Trọng số | Mô tả |
|------------|----------|-------|
| Workshop S1-01 | 10% | Hiểu tổng quan AI-Augmented Software Engineering |
| Workshop S1-02 | 15% | Phân tích repository, module map, workflow |
| Workshop S1-03 | 15% | Trình bày report và phản biện |
| **Tổng Slot 1** | **40%** | Nền tảng phân tích và tổ chức kiến thức |

### Slot 2 - Prompt, context và workflow AI
| Thành phần | Trọng số | Mô tả |
|------------|----------|-------|
| Workshop S2-01 | 10% | Prompt refinement |
| Workshop S2-02 | 10% | Context packing |
| Workshop S2-03 | 10% | Prompt playbook building |
| **Tổng Slot 2** | **30%** | Năng lực giao tiếp hiệu quả với AI |

### Slot 3 - Pair programming, feature development, review và reflection
| Thành phần | Trọng số | Mô tả |
|------------|----------|-------|
| Workshop S3-01 | 10% | Requirement to task breakdown |
| Workshop S3-02 | 15% | Feature implementation với AI |
| Workshop S3-03 | 5% | PR review và reflection |
| **Tổng Slot 3** | **30%** | Năng lực thực chiến end-to-end |

## 3. Rubric tổng hợp theo năng lực
| Năng lực | Trọng số | Biểu hiện đạt |
|----------|----------|---------------|
| Hiểu hệ thống | 20% | Đọc repo đúng, dựng module map và workflow rõ |
| Prompt engineering | 15% | Prompt rõ, có context, có output format |
| Context engineering | 10% | Chọn đúng file, đúng mức context |
| Verification | 15% | Có test, review, quality gate và kiểm chứng |
| Workflow với AI | 20% | Biết làm việc theo chuỗi requirement → code → review → PR |
| Reflection & responsibility | 10% | Ghi nhận bài học, biết giới hạn của AI |
| Deliverable quality | 10% | Nộp bài rõ ràng, có cấu trúc, có evidence |

## 4. Thang đánh giá chung
### Xuất sắc
- Hiểu đúng nội dung kỹ thuật.
- Deliverable rõ ràng, đầy đủ, có bằng chứng kiểm chứng.
- Dùng AI đúng cách, có phản biện và tự kiểm tra.
- Có insight riêng, không chỉ chép output AI.

### Đạt
- Hoàn thành phần lớn yêu cầu.
- Có deliverable hợp lệ.
- Có dùng AI và có kiểm chứng cơ bản.
- Còn thiếu chiều sâu hoặc thiếu consistency giữa các phần.

### Chưa đạt
- Nộp thiếu yêu cầu hoặc không bám task.
- Dùng AI nhưng không kiểm chứng.
- Deliverable mơ hồ, khó đánh giá.
- Không giải thích được quyết định kỹ thuật.

## 5. Gợi ý cách chấm
- Nên chấm theo rubric của từng workshop trước.
- Sau đó đối chiếu lại với rubric tổng hợp theo năng lực.
- Với bài theo nhóm, nên có thêm ghi chú đóng góp cá nhân.

## 6. Checklist chấm nhanh cho giảng viên
- [ ] Sinh viên hiểu đúng task.
- [ ] Có dùng đúng sample repository hoặc context yêu cầu.
- [ ] Có evidence từ code, test, report hoặc PR.
- [ ] Có kiểm chứng output AI.
- [ ] Có reflection hoặc self-review.
- [ ] Deliverable trình bày rõ ràng.
