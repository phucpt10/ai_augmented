# Module 2 - Codebase Understanding với Sample Repository

## 1. Mục tiêu
- Khám phá repository theo quy trình step-by-step.
- Dựng module map và business workflow.
- Viết onboarding notes cho người mới.

## 2. Bối cảnh
- **Module:** Module 2
- **Use case:** Team mới nhận một repository backend thương mại điện tử.
- **Repository:** Sample E-commerce Backend API
- **Tools:** VS Code, AI assistant, Git

## 3. Prerequisites
### 3.1 Setup
- [ ] Mở repository trong VS Code
- [ ] Đọc README và tree structure
- [ ] Xác định file entry point
- [ ] Chuẩn bị AI assistant

### 3.2 Sample Input
- Tree structure của repository
- README
- `userController.js`
- `orderController.js`
- `productRoutes.js`

## 4. Step-by-step Instructions
### Step 1: Repository overview
1. Đọc README để hiểu mục đích dự án.
2. Ghi lại ngôn ngữ, framework và database.
3. Xác định entry point và các folder chính.

### Step 2: Module identification
1. Liệt kê các module chính.
2. Xác định trách nhiệm của từng module.
3. Đánh dấu module nào tác động trực tiếp tới business flow.

### Step 3: Business workflow mapping
1. Chọn một luồng nghiệp vụ: đăng ký, tạo đơn hàng hoặc quản lý product.
2. Trace từ route đến controller.
3. Nếu cần, đọc thêm middleware và validation.

### Step 4: AI-assisted analysis
```text
Hãy phân tích repository sau theo 4 bước:
1. Overview
2. Module identification
3. Deep dive vào module quan trọng
4. Document findings

Input:
- Tree structure của repository
- README
- Nội dung các file: userController.js, orderController.js, productRoutes.js

Yêu cầu:
- Chỉ ra module chính
- Mô tả luồng nghiệp vụ
- Nêu dependency và rủi ro
- Đề xuất onboarding notes
```

### Step 5: Create deliverables
1. Viết Module Map.
2. Viết Project Understanding Report draft.
3. Viết onboarding notes.

### Step 6: Validate with code
1. Mở file thực tế và kiểm tra AI nói đúng chưa.
2. Ghi lại phần AI suy luận tốt.
3. Ghi lại phần cần bổ sung hoặc sửa.

## 5. Verification Checklist
- [ ] Module chính được xác định đúng.
- [ ] Luồng nghiệp vụ khớp với code.
- [ ] Dependency và rủi ro được nêu rõ.
- [ ] Onboarding notes đủ để người mới bắt đầu.

## 6. Expected Output
- Project Understanding Report draft.
- Module Map rõ ràng.
- Onboarding Notes ngắn gọn.

## 7. Common Mistakes
- Đọc quá ít file.
- Kết luận chưa kiểm chứng.
- Bỏ qua middleware hoặc validation.

## 8. Reflection Questions
- Phần nào của repository cần đọc thêm sau khi có module map?
- AI đã giúp rút ngắn bước nào nhất?

## 9. Facilitator Notes
- Ưu tiên dùng sample repository cho bài này.
- Có thể cho sinh viên làm theo nhóm 2 người.
