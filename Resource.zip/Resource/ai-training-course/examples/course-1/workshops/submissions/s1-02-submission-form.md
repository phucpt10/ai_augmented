# Submission Form - Workshop S1-02

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- Project Understanding Report draft.
- Module Map.
- Onboarding Notes.

## 3. Repository context
- Flow đã chọn:
- Files đã dùng:
- AI tool đã dùng:

## 4. Kết quả thực hiện
- Module chính tôi xác định:
- Luồng nghiệp vụ tôi trace:
- Dependency và rủi ro đã ghi nhận:

## 5. Evidence / kiểm chứng
- Tôi đã đối chiếu output AI với file nào:
- Điểm nào AI đúng:
- Điểm nào tôi phải sửa lại:

## 6. Reflection
- File nào quan trọng nhất để hiểu flow?
- Tôi còn cần đọc thêm phần nào của repository?
