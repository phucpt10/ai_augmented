# Workshop S1-03 - Project Understanding Presentation

## 1. Mục tiêu
- Trình bày hiểu biết về repository theo cấu trúc rõ ràng.
- Nhận phản biện và refine báo cáo.
- Chốt Project Understanding Report.

## 2. Yêu cầu
- Đã có draft report từ Workshop S1-02.
- Có module map và business workflow.
- Có slide hoặc outline trình bày.

## 3. Tài nguyên
- [Project Understanding Report template](../../../templates/project-understanding-report.md).
- Report draft từ S1-02.
- Module map.
- Business workflow.
- AI assistant.

## 4. Dữ liệu đầu vào
- Project Understanding Report draft.
- Một số file tiêu biểu của repository.

## 5. Hướng dẫn cho giảng viên
1. Cho học viên trình bày theo nhóm hoặc cá nhân.
2. Dừng ở các chỗ cần kiểm chứng bằng code.
3. Yêu cầu phản biện tập trung vào accuracy và completeness.
4. Nhắc học viên phân loại feedback thành must fix, should fix, nice to have.

## 6. Hướng dẫn cho sinh viên
### Bước 1: Ôn report
1. Đọc lại draft.
2. Gạch chân chỗ chưa rõ.

### Bước 2: Chuẩn bị trình bày
1. Tóm tắt project trong 3 phần: overview, architecture, workflow.
2. Chuẩn bị slide hoặc outline.

### Bước 3: Trình bày
1. Trình bày repository.
2. Trình bày architecture.
3. Trình bày business workflow.

### Bước 4: Review bằng AI
```text
Hãy review Project Understanding Report này như một senior engineer.

Yêu cầu:
1. Chỉ ra chỗ thiếu hoặc chưa rõ.
2. Kiểm tra độ chính xác của module map.
3. Gợi ý thêm security hoặc dependency notes.
4. Đề xuất action items cho người mới.
```

### Bước 5: Refine
1. Chỉnh report theo feedback.
2. Bổ sung action items.
3. Chốt report final.

## 7. Expected output
- Project Understanding Report hoàn chỉnh.
- Slide outline rõ ràng.

## 8. Verification checklist
- [ ] Trình bày được logic hệ thống.
- [ ] Module map khớp với code.
- [ ] Feedback được phản ánh.
- [ ] Report rõ cho người mới.

## 9. Reflection
- Điều gì thay đổi sau phản biện?
- Phần nào của report còn yếu?

## 10. Rubric chấm điểm
| Tiêu chí | Trọng số | Mô tả |
|----------|----------|-------|
| Nội dung report | 30% | Đầy đủ, chính xác và có cấu trúc |
| Chất lượng trình bày | 25% | Trình bày rõ, logic, dễ theo dõi |
| Phản hồi phản biện | 25% | Ghi nhận và xử lý feedback hợp lý |
| Bản final sau refine | 20% | Report sau chỉnh sửa tốt hơn bản draft rõ rệt |

### Mức đánh giá
- **Xuất sắc:** Trình bày mạch lạc, report chính xác, refine tốt.
- **Đạt:** Nội dung đủ nhưng trình bày hoặc phản hồi feedback còn hạn chế.
- **Chưa đạt:** Report thiếu, trình bày khó hiểu hoặc không xử lý feedback.
