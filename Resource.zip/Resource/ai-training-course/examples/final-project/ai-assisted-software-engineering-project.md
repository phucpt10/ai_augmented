# Final Project - AI-Assisted Software Engineering Project

## 1. Mục tiêu
- Tổng hợp toàn bộ kỹ năng từ Course 1, 2 và 3.
- Thể hiện workflow end-to-end với AI.

## 2. Bối cảnh
- **Tình huống:** Làm một project hoàn chỉnh hoặc một feature lớn trên repository thực tế.
- **Repository:** Sample repository hoặc project được giao
- **Tool sử dụng:** AI assistant, VS Code, Git, test runner, PR tool, reflection template

## 3. Dữ liệu đầu vào mẫu
### Prompt mẫu
```text
Hãy giúp tôi lên kế hoạch hoàn chỉnh cho feature/project này.

Yêu cầu:
1. Phân tích requirement.
2. Chia task.
3. Đề xuất test strategy.
4. Viết implementation plan.
5. Chỉ ra verification gate và rủi ro.
```

## 4. Các bước thực hiện
1. Chọn project hoặc feature.
2. Hiểu hệ thống và scope.
3. Lập kế hoạch, user story và test strategy.
4. Coding với AI.
5. Review, verify, refactor và document.
6. Tạo PR hoặc final package.
7. Viết reflection report.

## 5. Kiểm chứng kết quả
- Feature/project có hoàn thành đúng scope không?
- Có đủ test, documentation và review evidence không?
- Có reflection và bài học kinh nghiệm không?

## 6. Kết quả mong đợi
- Final Presentation
- Project Package
- Prompt Log
- Reflection Report
