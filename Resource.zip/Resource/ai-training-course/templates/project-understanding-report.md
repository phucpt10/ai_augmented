# Project Understanding Report

## Thông tin dự án

- **Tên dự án:** [Tên dự án]
- **Repository URL:** [Link repository]
- **Người phân tích:** [Tên của bạn]
- **Ngày phân tích:** [DD/MM/YYYY]
- **Phiên bản phân tích:** [Branch/Tag]

## 1. Tổng quan dự án

### 1.1 Mục đích dự án
[Mô tả ngắn gọn mục đích chính của dự án]

### 1.2 Ngôn ngữ và Framework
- **Ngôn ngữ chính:** [Ví dụ: Python, JavaScript, Java]
- **Framework:** [Ví dụ: React, Django, Spring Boot]
- **Database:** [Ví dụ: PostgreSQL, MongoDB]
- **Công cụ khác:** [Ví dụ: Docker, Kubernetes]

### 1.3 Cấu trúc Repository
```
[Mô tả cây thư mục chính của dự án]
```

## 2. Phân tích cấu trúc

### 2.1 Các module chính
| Module | Mô tả | File chính | Dependencies |
|--------|-------|------------|--------------|
| [Module 1] | [Mô tả] | [File path] | [List] |
| [Module 2] | [Mô tả] | [File path] | [List] |

### 2.2 Module Map
[Diagram hoặc mô tả mối quan hệ giữa các module]

## 3. Luồng nghiệp vụ (Business Workflow)

### 3.1 User Flow
[Mô tả luồng người dùng chính]

### 3.2 Data Flow
[Mô tả luồng dữ liệu trong hệ thống]

### 3.3 API Endpoints
| Endpoint | Method | Mô tả | Parameters |
|----------|--------|-------|------------|
| [/api/xxx] | GET | [Mô tả] | [List] |

## 4. Các thành phần quan trọng

### 4.1 Models/Entities
[List các model/entity quan trọng và mối quan hệ]

### 4.2 Services/Controllers
[List các service/controller và chức năng chính]

### 4.3 Utilities/Helpers
[List các utility functions quan trọng]

## 5. Cấu hình và Environment

### 5.1 Environment Variables
| Variable | Mô tả | Giá trị mặc định |
|----------|-------|------------------|
| [VAR_NAME] | [Mô tả] | [Default] |

### 5.2 Build và Deployment
- **Build command:** [Command]
- **Test command:** [Command]
- **Deployment:** [Mô tả quy trình]

## 6. Testing

### 6.1 Test Structure
[Mô tả cấu trúc thư mục test]

### 6.2 Test Coverage
[Thông tin về coverage nếu có]

### 6.3 Chạy test
- Command: [Command để chạy test]

## 7. Documentation

### 7.1 Available Documentation
- [ ] README.md
- [ ] API Documentation
- [ ] Architecture Documentation
- [ ] Contributing Guidelines
- [ ] Khác: [Specify]

### 7.2 Chất lượng documentation
[Đánh giá về chất lượng và độ đầy đủ của documentation]

## 8. AI-Assisted Analysis Notes

### 8.1 Các câu hỏi đã hỏi AI
[List các câu hỏi đã đặt cho AI để hiểu codebase]

### 8.2 Kết quả từ AI
[Tóm tắt các thông tin quan trọng nhận được từ AI]

### 8.3 Xác minh kết quả AI
[Mô tả cách bạn đã xác minh kết quả từ AI]

## 9. Vấn đề và quan sát

### 9.1 Vấn đề phát hiện
[List các vấn đề hoặc debt kỹ thuật phát hiện]

### 9.2 Điểm mạnh
[List các điểm mạnh của codebase]

### 9.2 Cải tiến đề xuất
[List các cải tiến có thể thực hiện]

## 10. Onboarding Notes cho thành viên mới

### 10.1 Bước đầu tiên
1. [Bước 1]
2. [Bước 2]
3. [Bước 3]

### 10.2 Resources quan trọng
- [Link/Resource 1]
- [Link/Resource 2]

### 10.3 Người liên hệ
- [Tên người liên hệ chính]
- [Kênh liên hệ: Slack, Email, etc.]

## 11. Kết luận

### 11.1 Độ hiểu biết hiện tại
[Đánh giá mức độ hiểu biết của bạn về dự án: 1-10]

### 11.2 Kế hoạch tiếp theo
[Các bước tiếp theo để hiểu sâu hơn về dự án]

---

**Lưu ý:** Đây là template, hãy điều chỉnh theo nhu cầu cụ thể của dự án.
