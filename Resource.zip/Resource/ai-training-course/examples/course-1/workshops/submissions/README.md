# Phiếu Nộp Bài Workshop - Course 1

Thư mục này chứa mẫu phiếu nộp bài cho sinh viên theo từng workshop. Mỗi phiếu được thiết kế để sinh viên nộp đúng deliverable, có evidence và có phần reflection ngắn.

## Danh mục phiếu nộp bài

### Slot 1
- [S1-01 Submission Form](s1-01-submission-form.md)
- [S1-02 Submission Form](s1-02-submission-form.md)
- [S1-03 Submission Form](s1-03-submission-form.md)

### Slot 2
- [S2-01 Submission Form](s2-01-submission-form.md)
- [S2-02 Submission Form](s2-02-submission-form.md)
- [S2-03 Submission Form](s2-03-submission-form.md)

### Slot 3
- [S3-01 Submission Form](s3-01-submission-form.md)
- [S3-02 Submission Form](s3-02-submission-form.md)
- [S3-03 Submission Form](s3-03-submission-form.md)

## Tài liệu liên quan
- [Course 1 Rubric Tổng Hợp](../course-1-rubric-overview.md)
- [Workshop System](../README.md)
