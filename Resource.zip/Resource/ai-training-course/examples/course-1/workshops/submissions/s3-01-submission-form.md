# Submission Form - Workshop S3-01

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- User story.
- Acceptance criteria.
- Task breakdown.
- Test strategy.

## 3. Requirement đã dùng
- Requirement gốc:
- Flow hoặc feature đã chọn:
- Files liên quan:

## 4. Kết quả thực hiện
- User story đã viết:
- Các task kỹ thuật chính:
- Edge cases đã xác định:
- Test cases chính:

## 5. Evidence / kiểm chứng
- Tôi đã dùng AI prompt nào:
- Tôi đã sửa output AI ở đâu:
- Những điểm tôi phải xác minh thủ công:

## 6. Reflection
- Requirement nào dễ bị hiểu sai nhất?
- Task breakdown của tôi đã đủ nhỏ và rõ chưa?
