# Submission Form - Workshop S2-02

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- Context pack ban đầu.
- Context pack đã refine.
- So sánh output tương ứng.

## 3. Context sử dụng
- Flow đã chọn:
- File ban đầu:
- File cuối cùng:

## 4. Kết quả thực hiện
- File nào tôi giữ lại:
- File nào tôi loại bỏ:
- Lý do chọn / bỏ:

## 5. Evidence / kiểm chứng
- Output với context ban đầu:
- Output với context refined:
- Điểm cải thiện rõ nhất:

## 6. Reflection
- Tôi đã học được gì về giới hạn context window?
- Tôi còn chọn context quá rộng hay quá hẹp ở chỗ nào?
