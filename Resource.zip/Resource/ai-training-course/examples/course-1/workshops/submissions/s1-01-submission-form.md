# Submission Form - Workshop S1-01

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- Bảng Task / Tool / Verification.
- Mô tả ngắn về vibe coding.
- Kết luận về human-in-the-loop.

## 3. Input đã dùng
- README / tree structure:
- File đại diện đã chọn:
- AI tool đã dùng:

## 4. Kết quả thực hiện
- Các nhóm việc AI hỗ trợ được:
- Công cụ tương ứng:
- Các task chỉ phù hợp prototype:
- Các task cần verification kỹ:

## 5. Evidence / kiểm chứng
- Tôi đã đối chiếu với code ở các file nào:
- Tôi đã xác minh điều gì bằng cách đọc code:

## 6. Reflection
- Tôi hiểu rõ hơn điều gì về AI-Augmented Software Engineering?
- Task nào tôi thấy dễ nhầm nhất?
