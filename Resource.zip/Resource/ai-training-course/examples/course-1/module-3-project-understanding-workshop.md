# Module 3 - Project Understanding Workshop

## 1. Mục tiêu
- Trình bày hiểu biết về repository theo cấu trúc rõ ràng.
- Nhận phản biện và refine báo cáo.

## 2. Bối cảnh
- **Module:** Module 3
- **Use case:** Workshop trình bày dự án đã phân tích ở Module 2.
- **Repository:** Sample E-commerce Backend API
- **Tools:** Project Understanding Report, slide hoặc Markdown, AI assistant

## 3. Prerequisites
### 3.1 Setup
- [ ] Có draft Project Understanding Report từ Module 2
- [ ] Có module map và business workflow
- [ ] Có file hoặc slide để trình bày

### 3.2 Sample Input
- Project Understanding Report draft
- Module map
- Business workflow
- Một số file tiêu biểu của repository

## 4. Step-by-step Instructions
### Step 1: Review the draft
1. Ôn lại báo cáo từ Module 2.
2. Đánh dấu chỗ còn mơ hồ hoặc thiếu bằng chứng.

### Step 2: Prepare presentation
1. Tóm tắt repository trong 3 phần: overview, architecture, workflow.
2. Chuẩn bị slide hoặc outline.

### Step 3: Present and review
1. Trình bày repository, architecture và business workflow.
2. Nhờ AI hoặc peer review để lấy phản hồi.

### Step 4: Use review prompt
```text
Hãy review Project Understanding Report này như một senior engineer.

Yêu cầu:
1. Chỉ ra chỗ thiếu hoặc chưa rõ.
2. Kiểm tra độ chính xác của module map.
3. Gợi ý thêm security hoặc dependency notes.
4. Đề xuất action items cho người mới.
```

### Step 5: Refine report
1. Chỉnh lại report theo phản hồi.
2. Bổ sung security, dependency và action items.
3. Chốt bản final.

## 5. Verification Checklist
- [ ] Trình bày được logic của hệ thống.
- [ ] Module map khớp với code.
- [ ] Peer feedback được phản ánh.
- [ ] Report rõ cho người mới.

## 6. Expected Output
- Project Understanding Report hoàn chỉnh.
- Bản trình bày rõ ràng cho stakeholder.

## 7. Common Mistakes
- Slide quá dài nhưng thiếu insight.
- Không dẫn chứng từ code.
- Bỏ qua security hoặc dependency.

## 8. Reflection Questions
- Bạn học được gì từ phản biện của peer?
- Report nào là phần yếu nhất cần cải thiện?

## 9. Facilitator Notes
- Dùng sample repository để sinh viên tập thuyết trình theo nhóm.
