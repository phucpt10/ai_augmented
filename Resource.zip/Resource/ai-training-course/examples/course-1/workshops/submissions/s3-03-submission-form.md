# Submission Form - Workshop S3-03

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- PR review summary.
- AI Decision Log entry.
- Reflection note.

## 3. PR context
- Tên PR hoặc feature:
- Files changed:
- Review scope:

## 4. Kết quả review
- Critical issues:
- Suggestions:
- Nice to have:
- Overall assessment:

## 5. Evidence / kiểm chứng
- Tôi đã đối chiếu review của AI với code ở đâu:
- Những điểm tôi sửa hoặc giữ lại sau review:

## 6. Reflection
- AI đúng ở đâu?
- AI sai hoặc thiếu ở đâu?
- Lần sau tôi sẽ chỉnh prompt review thế nào?
