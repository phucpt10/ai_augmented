# Submission Form - Workshop S1-03

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- Project Understanding Report final.
- Slide outline hoặc ghi chú trình bày.
- Danh sách feedback đã nhận và cách xử lý.

## 3. Kết quả trình bày
- Nội dung tôi đã trình bày:
- Phần được hỏi nhiều nhất:
- Feedback quan trọng nhất:

## 4. Evidence / kiểm chứng
- Những chỗ tôi phải quay lại code để xác minh:
- Những chỗ report đã được chỉnh sửa:

## 5. Reflection
- Sau phản biện, tôi hiểu rõ hơn phần nào?
- Nếu trình bày lại, tôi sẽ thay đổi điều gì?
