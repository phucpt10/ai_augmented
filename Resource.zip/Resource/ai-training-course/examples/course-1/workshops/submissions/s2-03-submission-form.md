# Submission Form - Workshop S2-03

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- Prompt Playbook tối thiểu cho 4 tác vụ.
- Ghi chú mục đích, context và output format cho từng prompt.

## 3. Playbook summary
- Các nhóm prompt đã có:
- Prompt mạnh nhất:
- Prompt cần cải thiện thêm:

## 4. Evidence / kiểm chứng
- Prompt nào đã test trên sample repository:
- Output nào ổn định nhất:
- Prompt nào chưa đạt kỳ vọng:

## 5. Reflection
- Prompt nào có giá trị tái sử dụng cao nhất?
- Nếu đưa playbook này cho nhóm khác dùng, tôi cần bổ sung gì?
