# Course 1 - 3 Slot Workshop Outline

Tài liệu này gom toàn bộ workshop của Course 1 thành 3 slot dạy, đồng thời đối chiếu các module để nhận diện phần trùng lắp và phần bổ trợ nhau.

## 1. Mục tiêu tổ chức workshop
- Giúp sinh viên đi theo một mạch học thống nhất từ hiểu hệ thống đến làm việc end-to-end với AI.
- Tạo ra các bài tập có mức độ tổng hợp tăng dần qua từng slot.
- Dùng chung sample repository để thấy rõ quan hệ giữa các module.
- Tránh lặp nội dung không cần thiết, nhưng vẫn cho phép lặp có chủ đích để củng cố kỹ năng.

## 2. Nguyên tắc thiết kế
- Một sample repository xuyên suốt cho toàn Course 1.
- Một business flow trung tâm xuyên suốt, ví dụ: user registration hoặc order creation.
- Mỗi slot có một deliverable rõ ràng.
- Mỗi workshop phải có input, thao tác, output và kiểm chứng.
- Mức tổng hợp tăng dần: hiểu -> hỏi AI đúng -> làm feature thật với AI.

## 3. Slot 1 - Nền tảng và hiểu hệ thống

### 3.1 Module áp dụng
- Module 1: Generative AI & AI-Augmented Software Engineering
- Module 2: AI-Assisted Codebase Understanding
- Module 3: Project Understanding Workshop

### 3.2 Mục tiêu slot
- Hiểu AI-Augmented Software Engineering ở mức tổng quan.
- Biết đọc repository, map module và business workflow.
- Trình bày được Project Understanding Report.

### 3.3 Đề cương workshop
#### Workshop 1A - Overview AI-Augmented SE
- Input: README, tree structure, 1-2 file đại diện
- Task: phân loại task AI hỗ trợ được, công cụ tương ứng, chỗ nào phù hợp vibe coding
- Output: bảng Task / Tool / Verification

#### Workshop 1B - Codebase exploration
- Input: README, controllers, routes, utils, validation
- Task: xác định module chính, trace luồng nghiệp vụ, dựng module map
- Output: Module Map + Onboarding Notes

#### Workshop 1C - Project understanding presentation
- Input: Project Understanding Report draft
- Task: trình bày và nhận phản biện
- Output: report final + slide outline

### 3.4 Mức độ tổng hợp
- Thấp đến trung bình.
- Chủ yếu là hiểu, phân tích, mô tả và trình bày.

### 3.5 Deliverables
- Project Understanding Report
- Module Map
- Onboarding Notes

## 4. Slot 2 - Prompt, context và workflow AI

### 4.1 Module áp dụng
- Module 4: Prompt Engineering for Software Engineering
- Module 5: Context Engineering & AI Coding Tools
- Module 6: Prompt Engineering Workshop

### 4.2 Mục tiêu slot
- Viết prompt tốt hơn.
- Chọn context tối thiểu nhưng đủ.
- Xây prompt playbook có thể tái sử dụng.

### 4.3 Đề cương workshop
#### Workshop 2A - Prompt refinement
- Input: prompt gốc quá chung chung
- Task: viết lại prompt cho explain code, review code, generate test
- Output: prompt trước/sau + lý do cải thiện

#### Workshop 2B - Context packing
- Input: 2-4 file liên quan trực tiếp đến một flow
- Task: chọn file cần thiết, loại file thừa, so sánh output theo từng context pack
- Output: context pack gọn mà đủ

#### Workshop 2C - Prompt playbook building
- Input: kết quả từ 2A và 2B
- Task: chuẩn hóa thành thư viện prompt dùng lại
- Output: Prompt Playbook cá nhân hoặc theo nhóm

### 4.4 Mức độ tổng hợp
- Trung bình.
- Người học phải nối file, mục tiêu, context, output format và tiêu chí đánh giá.

### 4.5 Deliverables
- Prompt Playbook
- Context Pack mẫu
- Bảng so sánh prompt yếu và prompt mạnh

## 5. Slot 3 - Pair programming, feature development, review và reflection

### 5.1 Module áp dụng
- Module 7: AI Pair Programming Workflow
- Module 8: AI-assisted Feature Development
- Module 9: Pull Request Review & AI Reflection

### 5.2 Mục tiêu slot
- Làm feature end-to-end với AI.
- Kiểm chứng output bằng test, review và PR.
- Ghi nhận bài học qua reflection và AI Decision Log.

### 5.3 Đề cương workshop
#### Workshop 3A - Requirement to task breakdown
- Input: requirement thực tế
- Task: viết user story, chia task, đề xuất test cases
- Output: user story + test strategy

#### Workshop 3B - AI-assisted feature implementation
- Input: user story + file liên quan
- Task: generate code, refine code, chạy test, refactor nếu cần
- Output: feature package + test evidence

#### Workshop 3C - PR review and reflection
- Input: PR diff và kết quả test
- Task: review PR, ghi AI Decision Log, viết reflection
- Output: PR package hoàn chỉnh + reflection report

### 5.4 Mức độ tổng hợp
- Cao.
- Đây là phần tổng hợp tất cả kỹ năng đã học trong Course 1.

### 5.5 Deliverables
- Feature package
- PR description
- Verification checklist
- AI Decision Log
- Reflection Report

## 6. Gợi ý sắp xếp theo buổi học

### Slot 1
- Buổi 1: Module 1 + phần đầu Module 2
- Buổi 2: phần còn lại của Module 2 + Module 3

### Slot 2
- Buổi 3: Module 4 + Module 5
- Buổi 4: Module 6

### Slot 3
- Buổi 5: Module 7
- Buổi 6: Module 8 + Module 9


## 7. Kết luận thiết kế
- Slot 1: hiểu hệ thống và tổ chức kiến thức.
- Slot 2: làm chủ prompt và context.
- Slot 3: thực chiến end-to-end với kiểm chứng.
- Các module 3, 6, 9 có overlap, nhưng đó là overlap có chủ đích để tăng khả năng ghi nhớ và chuyển giao kỹ năng.
