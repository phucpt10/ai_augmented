# Mẫu Ví Dụ Chuẩn

## 1. Mục tiêu
- Học viên sẽ làm được gì sau ví dụ này?
- Ví dụ này phục vụ bài học nào?

## 2. Bối cảnh
- **Module:** [Tên module]
- **Tình huống:** [Mô tả ngắn]
- **Repository:** [Sample repository hoặc mô tả giả lập nếu không cần repo]
- **Tool sử dụng:** [AI assistant, IDE, Git, test tool]

## 3. Dữ liệu đầu vào mẫu
- **File / đoạn code / requirement:**
  [Paste nội dung mẫu]
- **Prompt mẫu hoặc thao tác mẫu:**
  [Paste prompt hoặc lệnh]

## 4. Các bước thực hiện
1. Chuẩn bị môi trường hoặc mở repository.
2. Chọn đúng file, module hoặc context cần dùng.
3. Chạy prompt hoặc thao tác mẫu.
4. Quan sát output từ AI.
5. Chỉnh prompt hoặc context nếu kết quả chưa đạt.
6. Thực hiện verification.

## 5. Kiểm chứng kết quả
- Kết quả đúng với yêu cầu chưa?
- Có test hoặc manual check nào cần chạy không?
- Có rủi ro security, performance hoặc maintainability nào không?
- Có cần human review trước khi tiếp tục không?

## 6. Kết quả mong đợi
- [Kết quả 1]
- [Kết quả 2]
- [Kết quả 3]

## 7. Sai lầm thường gặp
- Dùng prompt quá chung chung
- Thiếu context hoặc context không đúng
- Không kiểm chứng output
- Bỏ qua security hoặc edge cases

## 8. Ghi chú cho giảng viên
- Điểm cần nhấn mạnh
- Câu hỏi gợi mở
- Phần có thể cho sinh viên làm độc lập
