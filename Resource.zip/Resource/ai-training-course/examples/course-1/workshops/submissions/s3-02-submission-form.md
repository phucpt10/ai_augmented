# Submission Form - Workshop S3-02

## 1. Thông tin sinh viên
- Họ và tên:
- Mã số sinh viên / ID:
- Nhóm (nếu có):
- Ngày nộp:

## 2. Deliverable cần nộp
- Feature implementation.
- Test evidence.
- Commit message.
- PR draft hoặc PR description.

## 3. Feature context
- Feature đã làm:
- Files thay đổi:
- AI tool đã dùng:
- Prompt chính đã dùng:

## 4. Kết quả thực hiện
- Code đã thêm / sửa:
- Test đã chạy:
- Review hoặc refactor đã thực hiện:

## 5. Evidence / kiểm chứng
- Kết quả test:
- Manual verification:
- Notes về rollback hoặc risk:

## 6. Reflection
- AI hỗ trợ tốt nhất ở bước nào?
- Bước nào tôi vẫn phải dựa vào kiểm tra thủ công nhiều nhất?
