# Course 2 - Documentation & Dependency Management

## 1. Mục tiêu
- Tạo tài liệu bàn giao, hướng dẫn dev và dependency analysis.
- Dùng AI để tổng hợp kiến thức từ repository.

## 2. Bối cảnh
- **Tình huống:** Member mới cần hiểu cách chạy project và các dependency chính.
- **Repository:** Sample E-commerce Backend API
- **Tool sử dụng:** AI assistant, Markdown editor, package manager

## 3. Dữ liệu đầu vào mẫu
### Prompt mẫu
```text
Hãy tạo onboarding document cho repository này.

Yêu cầu:
1. Mục đích hệ thống.
2. Cách cài đặt và chạy.
3. Các module chính.
4. Dependency quan trọng.
5. Những điều cần chú ý khi thay đổi code.
```

## 4. Các bước thực hiện
1. Đọc README và package files.
2. Gom danh sách dependency chính.
3. Hỏi AI tóm tắt cách chạy project.
4. Tạo onboarding guide.
5. Kiểm chứng lại bằng cách chạy lệnh cài đặt hoặc test.

## 5. Kiểm chứng kết quả
- Hướng dẫn có chạy được thật không?
- Có thiếu bước cài đặt nào không?
- Có nói rõ risk khi sửa module quan trọng không?

## 6. Kết quả mong đợi
- Developer Handbook hoặc onboarding notes.
